import java.util.Scanner;
public class Assignment4 {
 public static void main(String[] args) {
 Scanner scanner = new Scanner(System.in);
 // Input: number of days in the week
 System.out.print("Enter the number of days in the week: ");
 int numberOfDays = scanner.nextInt();
 double[] temperatures = new double[numberOfDays];
 // Input: daily high temperatures
 for (int i = 0; i < numberOfDays; i++) {
 System.out.print("Enter the high temperature for day " + (i + 1) + ": ");
 temperatures[i] = scanner.nextDouble();
 }
 // Calculations
 double total = 0;
 double highest = temperatures[0];
 double lowest = temperatures[0];
 int daysAbove80 = 0;
 int daysBelow60 = 0;
 for (int i = 0; i < numberOfDays; i++) {
 double temp = temperatures[i];
 total += temp;
 if (temp > highest) {
 highest = temp;
 }
 if (temp < lowest) {
 lowest = temp;
 }
 if (temp > 80) {
 daysAbove80++;
 }
 if (temp < 60) {
 daysBelow60++;
 }
 }
 double average = total / numberOfDays;
 // Display results
 System.out.println("---------------------------------");
 System.out.println("Average Daily Temperature: " + average);
 System.out.println("Highest Daily Temperature: " + highest);
 System.out.println("Lowest Daily Temperature: " + lowest);
 System.out.println("Days above 80 degrees F: " + daysAbove80);
 System.out.println("Days below 60 degrees F: " + daysBelow60);
 scanner.close();}}