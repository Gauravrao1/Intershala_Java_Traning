import java.util.Random;
public class Assignment2 {
 public static void main(String[] args) {
 // 1. Define predefined winning score
 int winningScore = 50;
 int player1Score = 0;
 int player2Score = 0;
 Random random = new Random();
 int round = 1;
 // 2 & 3 & 4. Simulate the dice game until someone wins
 while (player1Score < winningScore && player2Score < winningScore) {
 int player1Roll = random.nextInt(6) + 1; // 1 to 6
 int player2Roll = random.nextInt(6) + 1; // 1 to 6
 player1Score += player1Roll;
 player2Score += player2Roll;
 System.out.println("Round " + round + ":");
 System.out.println(" Player 1 rolled " + player1Roll + " -> Total Score: " + player1Score);
 System.out.println(" Player 2 rolled " + player2Roll + " -> Total Score: " + player2Score);
 round++;
 }
 // 5. Display the winner and final scores
 System.out.println("---------------------------------");
 if (player1Score >= winningScore && player2Score >= winningScore) {
 // Both crossed in the same round - higher score wins
 if (player1Score > player2Score) {
 System.out.println("Player 1 wins with a score of " + player1Score + "!");
 } else if (player2Score > player1Score) {
 System.out.println("Player 2 wins with a score of " + player2Score + "!");
 } else {
 System.out.println("It's a tie! Both players scored " + player1Score + "!");
 }
 } else if (player1Score >= winningScore) {
 System.out.println("Player 1 wins with a final score of " + player1Score + "!");
 } else {
 System.out.println("Player 2 wins with a final score of " + player2Score + "!");
 }
 }
}
