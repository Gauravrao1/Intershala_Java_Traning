public class Assignment3 {
 public static void main(String[] args) {
 // Predefined input sentence (no user input, as per problem style)
 String sentence = "Hello World Java";
 // Split the sentence into words
 String[] words = sentence.split(" ");
 // Build the reversed sentence
 StringBuilder reversed = new StringBuilder();
 for (int i = words.length - 1; i >= 0; i--) {
 reversed.append(words[i]);
 if (i != 0) {
 reversed.append(" ");
 }
 }
 // Print original and reversed sentence
 System.out.println("Original Sentence: " + sentence);
 System.out.println("Reversed Sentence: " + reversed.toString());
 }
}
