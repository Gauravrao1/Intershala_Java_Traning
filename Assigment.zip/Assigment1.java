public class Assigment1{
 public static void main(String[] args) {
 // 1. Define variables with predefined values
 double itemPrice = 10.00;
 int numberOfItems = 5;
 double taxRate = 8; // 8%
 double discountPercentage = 10; // 10%
 // 2. Calculate values
 double subtotal = itemPrice * numberOfItems;
 double discountAmount = subtotal * (discountPercentage / 100);
 double amountAfterDiscount = subtotal - discountAmount;
 double taxAmount = amountAfterDiscount * (taxRate / 100);
 double totalCost = amountAfterDiscount + taxAmount;
 // Display results
 System.out.println("Item Price: $" + itemPrice);
 System.out.println("Number of Items: " + numberOfItems);
 System.out.println("Tax Rate: " + taxRate + "%");
 System.out.println("Discount Percentage: " + discountPercentage + "%");
 System.out.println("---------------------------------");
 System.out.println("Subtotal: $" + subtotal);
 System.out.println("Discount Amount: $" + discountAmount);
 System.out.println("Tax Amount: $" + taxAmount);
 System.out.println("Total Cost: $" + totalCost);
 }
}
